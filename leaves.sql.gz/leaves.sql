-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 02, 2014 at 11:46 PM
-- Server version: 5.5.31
-- PHP Version: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `leaves`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `post_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `email`, `website`, `message`, `post_id`, `created_at`, `updated_at`) VALUES
(1, 'iva', 'momcilovicivana@yahoo.com', 'dasdsadas', 'sadasdasd', 1, 1404031335, 1404031335);

-- --------------------------------------------------------

--
-- Table structure for table `installed_rules`
--

CREATE TABLE IF NOT EXISTS `installed_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `element` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `installed_rules`
--

INSERT INTO `installed_rules` (`id`, `name`, `element`) VALUES
(20, 'end_date_required', 'PGxhYmVsIGZvcj0nZW5kX2RhdGVfcmVxdWlyZWQnPklzIGVuZCBkYXRlIHJlcXVpcmVkPzwvbGFiZWw+PGlucHV0IHR5cGU9J2NoZWNrYm94JyBpZD0nZW5kX2RhdGVfcmVxdWlyZWQnIG5hbWU9J2VuZF9kYXRlX3JlcXVpcmVkJyAvPg=='),
(21, 'auto_approve', 'PGxhYmVsIGZvcj0nYXV0b19hcHByb3ZlJz5JcyBhdXRvbWF0aWNhbGx5IGFwcHJvdmVkIHVwb24gY3JlYXRpb24/PC9sYWJlbD48aW5wdXQgdHlwZT0nY2hlY2tib3gnIGlkPSdhdXRvX2FwcHJvdmUnIG5hbWU9J2F1dG9fYXBwcm92ZScgLz4='),
(22, 'paid', 'PGxhYmVsIGZvcj0ncGFpZCc+SXMgbGVhdmUgcGFpZD88L2xhYmVsPjxpbnB1dCB0eXBlPSdjaGVja2JveCcgaWQ9J3BhaWQnIG5hbWU9J3BhaWQnIC8+'),
(23, 'exclude_holiday', 'PGxhYmVsIGZvcj0nZXhjbHVkZV9ob2xpZGF5Jz5Ib2xpZGF5IHNob3VsZCBiZSBzdWJzdHJhY3RlZCBmcm9tIG51bWJlciBvZiB0aGUgZGF5cz88L2xhYmVsPjxpbnB1dCB0eXBlPSdjaGVja2JveCcgaWQ9J2V4Y2x1ZGVfaG9saWRheScgbmFtZT0nZXhjbHVkZV9ob2xpZGF5JyAvPg=='),
(24, 'book_in_advance', 'PGxhYmVsIGZvcj0nYm9va19pbl9hZHZhbmNlJz5NdXN0IGJlIGJvb2tlZCBpbiBhZHZhbmNlPC9sYWJlbD48aW5wdXQgdHlwZT0ndGV4dCcgaWQ9J2Jvb2tfaW5fYWR2YW5jZScgbmFtZT0nYm9va19pbl9hZHZhbmNlJyAvPg=='),
(25, 'same_time_users', 'PGxhYmVsIGZvcj0nc2FtZV90aW1lX3VzZXJzJz5NYXhpbXVtIGFsbG93ZWQgdXNlcnMgYXQgdGhlIHNhbWUgdGltZTwvbGFiZWw+PGlucHV0IHR5cGU9J3RleHQnIGlkPSdzYW1lX3RpbWVfdXNlcnMnIG5hbWU9J3NhbWVfdGltZV91c2VycycgLz4='),
(26, 'days_allowed', 'PGxhYmVsIGZvcj0nZGF5c19hbGxvd2VkJz5EYXlzIGFsbG93ZWQgaW4gcGVyaW9kPC9sYWJlbD48aW5wdXQgdHlwZT0ndGV4dCcgaWQ9J2RheXNfYWxsb3dlZCcgbmFtZT0nZGF5c19hbGxvd2VkJyAvPjxzZWxlY3QgbmFtZT0nZGF5c19hbGxvd2VkX29wdGlvbic+PG9wdGlvbiB2YWx1ZT0nZGF5cyc+ZGF5czxvcHRpb24+PG9wdGlvbiB2YWx1ZT0nbW9udGgnPm1vbnRoPG9wdGlvbj48b3B0aW9uIHZhbHVlPSd5ZWFyJz55ZWFyPG9wdGlvbj48L3NlbGVjdD4=');

-- --------------------------------------------------------

--
-- Table structure for table `leave`
--

CREATE TABLE IF NOT EXISTS `leave` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `note` text NOT NULL,
  `approved` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `leave`
--

INSERT INTO `leave` (`id`, `user`, `type`, `start`, `end`, `note`, `approved`) VALUES
(1, 1, '1', '0000-00-00', '0000-00-00', 'ssf', 0),
(2, 1, '10', '2014-07-11', '2014-07-14', 'vcvcv', 0),
(3, 1, '1', '2014-07-19', '2014-07-23', '', 0),
(4, 1, '1', '2014-07-10', '2014-07-30', '', 1),
(5, 1, '13', '2014-07-17', '2014-07-24', '', 1),
(6, 1, '1', '2014-07-10', '0000-00-00', '', 1),
(7, 1, '13', '2014-07-24', '2014-07-14', '', 1),
(8, 1, '22', '2014-07-25', '2014-07-18', '', 1),
(9, 1, '22', '2014-07-03', '2014-07-23', '', 1),
(10, 1, '22', '2014-07-16', '2014-07-29', '', 1),
(11, 1, '22', '2014-07-16', '2014-07-08', '', 1),
(12, 1, '24', '2014-07-18', '2014-07-24', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `leavetype`
--

CREATE TABLE IF NOT EXISTS `leavetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `end_date_required` varchar(255) DEFAULT NULL,
  `auto_approve` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `exclude_holiday` varchar(255) DEFAULT NULL,
  `book_in_advance` varchar(255) DEFAULT NULL,
  `same_time_users` varchar(255) DEFAULT NULL,
  `days_allowed` varchar(255) DEFAULT NULL,
  `days_allowed_option` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `leavetype`
--

INSERT INTO `leavetype` (`id`, `name`, `end_date_required`, `auto_approve`, `paid`, `exclude_holiday`, `book_in_advance`, `same_time_users`, `days_allowed`, `days_allowed_option`) VALUES
(1, 'end_date_required-on_paid-on_book_in_advance-3_same_time_users-6_', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'auto_approve-on_book_in_advance-7_same_time_users-3_', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'book_in_advance-fdf_same_time_users-dsfdsfsd_', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'auto_approve-on_book_in_advance-435_same_time_users-4545_', NULL, 'on', NULL, NULL, '435', '4545', NULL, NULL),
(11, 'paid-on_book_in_advance-3434_', NULL, NULL, 'on', NULL, '3434', '', NULL, NULL),
(12, '', NULL, NULL, NULL, NULL, '', '', NULL, NULL),
(13, 'auto_approve-on_book_in_advance-45_same_time_users-54_', NULL, 'on', NULL, NULL, '45', '54', NULL, NULL),
(14, 'days_allowed-4_', NULL, NULL, NULL, NULL, '', '', '4', NULL),
(15, 'days_allowed-4_', NULL, NULL, NULL, NULL, '', '', '4', NULL),
(16, 'days_allowed-6_month_', NULL, NULL, NULL, NULL, '', '', '6', NULL),
(17, 'book_in_advance-55_same_time_users-44_days_allowed-3_year_', NULL, NULL, NULL, NULL, '55', '44', '3', NULL),
(18, 'days_allowed-4_month_', NULL, NULL, NULL, NULL, '', '', '4', NULL),
(19, 'days_allowed-5_month_', NULL, NULL, NULL, NULL, '', '', '5', 'month'),
(20, 'end_date_required-on_paid-on_days_allowed-4_days_days_allowed-4_days_', 'on', NULL, 'on', NULL, '', '', '4', 'days'),
(21, 'end_date_required-on_paid-on_book_in_advance-2_days_days_', 'on', NULL, 'on', NULL, '2', '', '', 'days'),
(22, 'end_date_required-on_auto_approve-on_paid-on_exclude_holiday-on_book_in_advance-3_same_time_users-4_days_', 'on', 'on', 'on', 'on', '3', '4', '', 'days'),
(23, 'auto_approve-on_paid-on_exclude_holiday-on_book_in_advance-4_same_time_users-3_days_allowed-3_month_', NULL, 'on', 'on', 'on', '4', '3', '3', 'month'),
(24, 'end_date_required-on_paid-on_exclude_holiday-on_book_in_advance-3_same_time_users-3_days_allowed-3_month_', 'on', NULL, 'on', 'on', '3', '3', '3', 'month');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `type` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `migration` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`type`, `name`, `migration`) VALUES
('app', 'default', '001_create_users'),
('app', 'default', '002_create_posts'),
('app', 'default', '003_create_comments');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `body` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `summary`, `body`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'dsdgds', 'dsdgds', 'gdgdfgfdg', 'fgfdgfg', 1, 1404030054, 1404031335),
(2, 'dfdfdf', 'dfdfdf', 'ffffff', 'fsdfsfsf', 1, 1404030204, 1404030204);

-- --------------------------------------------------------

--
-- Table structure for table `rules`
--

CREATE TABLE IF NOT EXISTS `rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `has_options` tinyint(3) DEFAULT NULL,
  `options_type` varchar(255) NOT NULL,
  `required` tinyint(3) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `rules`
--

INSERT INTO `rules` (`id`, `name`, `type`, `label`, `has_options`, `options_type`, `required`, `created_at`, `updated_at`) VALUES
(1, 'End date required', 'checkbox', 'Is end date required?', NULL, 'select', NULL, 1404037194, 1404037194);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `last_login` int(11) NOT NULL,
  `login_hash` varchar(255) NOT NULL,
  `profile_fields` text NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `group`, `email`, `last_login`, `login_hash`, `profile_fields`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'NtgTF8q6Z9UyyUwQS7Ma5Bvj+uTrK/F66iMji9su1XY=', 100, 'phil@example.com', 1404330238, '5ee04585243e1af153d4750f663d0685ea2077cc', 'a:0:{}', 1404028548, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
